<?php
require_once (dirname(dirname(__FILE__)) . '/memplugin.class.php');
class memPlugin_mysql extends memPlugin {}