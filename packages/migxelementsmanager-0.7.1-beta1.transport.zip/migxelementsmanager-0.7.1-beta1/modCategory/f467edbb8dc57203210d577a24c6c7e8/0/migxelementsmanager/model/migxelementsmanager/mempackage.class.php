<?php
class memPackage extends xPDOSimpleObject {}