<?php
require_once (dirname(dirname(__FILE__)) . '/memtemplatevar.class.php');
class memTemplateVar_mysql extends memTemplateVar {}