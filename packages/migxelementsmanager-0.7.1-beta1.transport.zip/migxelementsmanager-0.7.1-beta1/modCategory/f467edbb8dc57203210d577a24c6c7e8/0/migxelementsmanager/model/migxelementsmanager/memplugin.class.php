<?php
class memPlugin extends xPDOSimpleObject {}