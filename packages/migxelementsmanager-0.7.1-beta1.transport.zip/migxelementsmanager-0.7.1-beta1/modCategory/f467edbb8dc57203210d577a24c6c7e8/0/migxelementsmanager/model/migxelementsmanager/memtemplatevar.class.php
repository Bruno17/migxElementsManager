<?php
class memTemplateVar extends xPDOSimpleObject {}