<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 
    array (
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'eb7c93599b1af28c7d5dcf299b913524',
      'native_key' => 'migxelementsmanager',
      'filename' => 'modNamespace/3f9a5d1e31e23b86303d1ff4bcce93f9.vehicle',
      'namespace' => 'migxelementsmanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1fe169dc65c66029c1895bd048d09b28',
      'native_key' => 1,
      'filename' => 'modCategory/f954a9a001290f65b647adbac4585dca.vehicle',
      'namespace' => 'migxelementsmanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'afca589dd9eafc2df37514940146856b',
      'native_key' => 'migxElementsManager',
      'filename' => 'modMenu/21e3e9cc3a814c000005404e962d4f36.vehicle',
      'namespace' => 'migxelementsmanager',
    ),
  ),
);