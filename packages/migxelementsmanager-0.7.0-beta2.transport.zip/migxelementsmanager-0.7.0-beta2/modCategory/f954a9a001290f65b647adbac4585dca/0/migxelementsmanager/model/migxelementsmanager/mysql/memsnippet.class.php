<?php
require_once (dirname(dirname(__FILE__)) . '/memsnippet.class.php');
class memSnippet_mysql extends memSnippet {}