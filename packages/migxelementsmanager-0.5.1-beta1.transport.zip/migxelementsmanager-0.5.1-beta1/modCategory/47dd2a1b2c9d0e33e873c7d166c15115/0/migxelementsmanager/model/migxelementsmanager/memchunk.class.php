<?php
class memChunk extends xPDOSimpleObject {}