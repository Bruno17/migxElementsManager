<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'memSnippet',
    1 => 'memChunk',
    2 => 'memTemplate',
    3 => 'memPlugin',
    4 => 'memTemplateVar',
    5 => 'memCategory',
  ),
);