<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 
    array (
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4e21a1bcf3eaf0bd44ba42a97a243a07',
      'native_key' => 'migxelementsmanager',
      'filename' => 'modNamespace/f75766e0cdac7d74efe5c1c8edec4091.vehicle',
      'namespace' => 'migxelementsmanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3dc3badff57a7e88ee612dea0241d5ee',
      'native_key' => 1,
      'filename' => 'modCategory/a07226932dc84522117aa146a11c8b1d.vehicle',
      'namespace' => 'migxelementsmanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '29d46f8ceccb01fb8a2bb59317b24786',
      'native_key' => 'migxElementsManager',
      'filename' => 'modMenu/645157b15192cd3acea73a369f6aac39.vehicle',
      'namespace' => 'migxelementsmanager',
    ),
  ),
);