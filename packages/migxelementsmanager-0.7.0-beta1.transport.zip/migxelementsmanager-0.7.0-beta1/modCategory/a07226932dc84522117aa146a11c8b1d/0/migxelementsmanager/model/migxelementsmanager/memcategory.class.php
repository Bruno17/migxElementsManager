<?php
class memCategory extends xPDOSimpleObject {}