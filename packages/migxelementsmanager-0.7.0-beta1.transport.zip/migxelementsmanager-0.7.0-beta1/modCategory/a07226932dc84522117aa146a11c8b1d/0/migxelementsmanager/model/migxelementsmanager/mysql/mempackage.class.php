<?php
require_once (dirname(dirname(__FILE__)) . '/mempackage.class.php');
class memPackage_mysql extends memPackage {}