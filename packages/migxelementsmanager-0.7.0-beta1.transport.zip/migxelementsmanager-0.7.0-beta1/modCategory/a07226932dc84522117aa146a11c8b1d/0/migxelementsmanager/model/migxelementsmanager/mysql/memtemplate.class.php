<?php
require_once (dirname(dirname(__FILE__)) . '/memtemplate.class.php');
class memTemplate_mysql extends memTemplate {}