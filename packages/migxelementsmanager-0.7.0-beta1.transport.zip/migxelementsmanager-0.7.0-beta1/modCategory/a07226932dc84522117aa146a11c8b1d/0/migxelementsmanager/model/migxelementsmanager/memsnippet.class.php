<?php
class memSnippet extends xPDOSimpleObject {}