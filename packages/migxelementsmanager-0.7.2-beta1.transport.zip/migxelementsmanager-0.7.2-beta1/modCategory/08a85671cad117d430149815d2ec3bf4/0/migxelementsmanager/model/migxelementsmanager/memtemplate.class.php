<?php
class memTemplate extends xPDOSimpleObject {}