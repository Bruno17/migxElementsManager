<?php
require_once (dirname(dirname(__FILE__)) . '/memcategory.class.php');
class memCategory_mysql extends memCategory {}