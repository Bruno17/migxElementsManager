<?php
require_once (dirname(dirname(__FILE__)) . '/memchunk.class.php');
class memChunk_mysql extends memChunk {}